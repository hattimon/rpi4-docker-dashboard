from flask import Flask, jsonify, render_template, request
import subprocess
import json
import os

app = Flask(__name__, template_folder='/root/panel/templates')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/status')
def status():
    cpu = subprocess.getoutput("top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\\([0-9.]*\\)%* id.*/\\1/' | awk '{print 100-$1"%"}'")
    ram = subprocess.getoutput("free | grep Mem | awk '{printf "%.1f%", $3/$2 * 100}'")
    temp = subprocess.getoutput("vcgencmd measure_temp 2>/dev/null | cut -d '=' -f2")
    disk = subprocess.getoutput("df -h / | tail -1 | awk '{print $5}'")
    eth_ip = subprocess.getoutput("ip addr show eth0 | grep 'inet ' | awk '{print $2}' | cut -d/ -f1 || echo 'brak'")
    wifi_ip = subprocess.getoutput("ip addr show wlan0 | grep 'inet ' | awk '{print $2}' | cut -d/ -f1 || echo 'brak'")
    containers = json.loads(subprocess.getoutput("docker ps --format '{"name":"{{.Names}}","image":"{{.Image}}","status":"{{.Status}}"}' | jq -s '.'"))
    current_wifi = subprocess.getoutput("iwgetid -r || echo 'brak'")

    return jsonify({
        "system": {"cpu": cpu, "ram": ram, "temp": temp, "disk": disk},
        "network": {"eth0": eth_ip, "wlan0": wifi_ip},
        "containers": containers,
        "wifi": {"current": current_wifi}
    })

@app.route('/wifi/scan')
def wifi_scan():
    try:
        result = subprocess.getoutput("sudo iwlist wlan0 scan | grep ESSID | awk -F':' '{print $2}' | tr -d '"'")
        networks = list(set(result.splitlines()))
        return jsonify({"networks": networks})
    except:
        return jsonify({"networks": [], "error": "Skanowanie nie powiodło się"})

@app.route('/wifi/connect', methods=['POST'])
def wifi_connect():
    data = request.get_json()
    ssid = data.get('ssid')
    password = data.get('password')
    try:
        with open('/etc/wpa_supplicant/wpa_supplicant.conf', 'w') as f:
            f.write(f"""ctrl_interface=DIR=/var/run/ wpa_supplicant
network={{
    ssid="{ssid}"
    psk="{password}"
}}
""")
        subprocess.run(['sudo', 'wpa_cli', '-i', 'wlan0', 'reconfigure'], check=True)
        return jsonify({"status": "success"})
    except:
        return jsonify({"status": "error"})

@app.route('/wifi/forget', methods=['POST'])
def wifi_forget():
    try:
        with open('/etc/wpa_supplicant/wpa_supplicant.conf', 'w') as f:
            f.write("ctrl_interface=DIR=/var/run/ wpa_supplicant\n")
        subprocess.run(['sudo', 'wpa_cli', '-i', 'wlan0', 'reconfigure'], check=True)
        return jsonify({"status": "success"})
    except:
        return jsonify({"status": "error"})

@app.route('/restart/<name>')
def restart_container(name):
    try:
        subprocess.run(['docker', 'restart', name], check=True)
        return jsonify({"status": "success"})
    except:
        return jsonify({"status": "error"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
